export INSTANA_DOWNLOAD_KEY=
export INSTANA_SALES_KEY=
export INSTANA_AGENT_KEY=

export INSTANA_HOST=instana.gcgcsm.com


# 01. images secret

kubectl create secret docker-registry instana-registry --namespace instana-operator \
    --docker-username=xxx \
    --docker-password=xxx \
    --docker-server=swr.cn-north-4.myhuaweicloud.com

kubectl create secret docker-registry instana-registry --namespace instana-units \
    --docker-username=xxx \
    --docker-password=xxx \
    --docker-server=swr.cn-north-4.myhuaweicloud.com

kubectl create secret docker-registry instana-registry --namespace instana-core \
    --docker-username=xxx \
    --docker-password=xxx \
    --docker-server=swr.cn-north-4.myhuaweicloud.com


# 02. create instana operator

cat <<EOF > ./operator-values.yaml < EOF
image:
  registry: swr.cn-north-4.myhuaweicloud.com

imagePullSecrets:
  - name: instana-registry
EOF

mkdir template
kubectl instana operator template --output-dir ./template --namespace=instana-operator --values ./operator-values.yaml
kubectl apply -f ./template


# 03. instana base secret
mkdir ./tmp
kubectl instana license download --sales-key=${INSTANA_SALES_KEY}


# 04. instana-tls secret
mkdir ./tmp/instana-tls
openssl req -x509 -newkey rsa:2048 -keyout ./tmp/instana-tls/tls.key -out ./tmp/instana-tls/tls.crt -days 3650 -nodes -subj "/CN=$INSTANA_HOST"
kubectl create secret tls instana-tls --namespace instana-core --cert=./tmp/instana-tls/tls.crt --key=./tmp/instana-tls/tls.key
kubectl label secret instana-tls   app.kubernetes.io/name=instana -n instana-core

# 05 instana core config

openssl dhparam -out ./tmp/dhparams.pem 2048


mkdir ./tmp/instana-service-provider
# Create the key, `Passw0rd` as pass phrase
openssl genrsa -aes128 -out ./tmp/instana-service-provider/key.pem 2048

# Create the certificate
openssl req -new -x509 -key ./tmp/instana-service-provider/key.pem -out ./tmp/instana-service-provider/cert.pem -days 3650

# Combine the two into a single file
cat ./tmp/instana-service-provider/key.pem ./tmp/instana-service-provider/cert.pem > ./tmp/instana-service-provider/sp.pem

kubectl create secret generic instana-core --namespace instana-core --from-file=path/to/config.yaml

#06. instana unit config


kubectl create secret generic tenant0-unit0 --namespace instana-core --from-file=./core/config.yaml